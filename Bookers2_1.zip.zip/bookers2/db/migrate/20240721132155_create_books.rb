class CreateBooks < ActiveRecord::Migration[5.2]
  
  belongs_to :user
  
  def change
    add_column :users, :image, :string
  end
  
  def change
    create_table :books do |t|
      t.text :title
      t.text :body
      t.integer :user_id

      t.timestamps
    end
    
  
  end
end
