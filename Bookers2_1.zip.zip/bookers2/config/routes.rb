Rails.application.routes.draw do
  # get 'users/index'  # 削除
  # get 'users/show'   # 削除
  # get 'users/edit'   # 削除
  devise_for :users
  root to: 'homes#top'
  get 'home/about', to: 'homes#about'
  resources :users, only: [:index, :show, :edit, :update]
  resources :books, only: [:new, :create, :index, :show, :destroy, :edit, :update]
  post 'users' => 'books#create'
  get 'books' => 'books#index'
end
