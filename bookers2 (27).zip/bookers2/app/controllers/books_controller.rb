class BooksController < ApplicationController
  
  before_action :set_book, only: %i[show edit update destroy]
  before_action :authenticate_user!
  before_action :authorize_user!, only: %i[edit update destroy]


  def new
    @book = Book.new
  end

  def create
    @book = Book.new(book_params)
    @book.user_id = current_user.id  # 投稿したのはログインユーザーのため current_userを代入

    if @book.save
      # 成功時
      redirect_to @book, notice: 'You have updated book successfully.'  # books#showにリダイレクト
    else
      # 失敗時（Lesson6 - Chapter8などで学習したように、ビューファイルでエラーメッセージを表示）
      @user = current_user
      @books = Book.all  # `@books`を設定
      render :index  # books#indexをrender
    end
  end

  def index
    @user = current_user
    @books = Book.all
    @book = Book.new
    @book_new = Book.new
  end

  def show
    @book = Book.find(params[:id])
    @user = @book.user
    @book_new = Book.new  # 投稿用（form_with用）
  end

  def edit
    @book = Book.find(params[:id])
  end

  def destroy
    book = Book.find(params[:id])
    book.destroy
    redirect_to books_path
  end
  
  def update
    @book = Book.find(params[:id])
    if @book.update(book_params)
      redirect_to @book, notice: 'Book was successfully updated.'
    else
      render :edit
    end
  end


private

  def book_params
    params.require(:book).permit(:title, :body)
  end

  def set_book
    @book = Book.find(params[:id])
  end

  def authorize_user!
    redirect_to books_path, alert: 'Not authorized to edit this book' unless @book.user == current_user
  end
end